let pTag=document.querySelector("p")
document.addEventListener("keypress",function(event){
    let text = event.key;
    pTag.innerHTML =text
})